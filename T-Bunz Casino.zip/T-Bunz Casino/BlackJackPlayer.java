// Tyler Bunnell
// This program plays a standard game of Black Jack

import java.util.*;

public class BlackJackPlayer {
   
   private int bank;
   private ArrayList<String> dealer;
   private ArrayList<String> user;
   private FiftyTwoCardDeck deck;
   private int bet;
   private boolean usersTurn;
   private Scanner console;
   
   // Constructor
   public BlackJackPlayer(int bank) {
      this.bank = bank;
      this.dealer = new ArrayList<>();
      this.user = new ArrayList<>();
      this.deck = new FiftyTwoCardDeck();
      this.bet = -1;
      this.console = new Scanner(System.in);
   }
   
   // Puts all of the methods together to play the game
   public int play() {
      String yesNo = "y";
      while(yesNo.startsWith("y") && bank > 0) {
         deck.reset();
         deck.shuffle();
         int bet = -1;
         startUp();
         int turn = goUserGo();
         if(deck.findValueBJ(user) > 21) {
            System.out.println(deck.showBJTable(user, dealer, false));
            System.out.println("Oh no, you busted!");
         } else if(deck.findValueBJ(user) == 21 && turn == 0){
            System.out.println("Black Jack!! You win!!");
            win();
         } else {
            dealersTurn();
            whoWins();
         }
         user.clear();
         dealer.clear();
         if(bank > 0) {
            System.out.println("You have $" + bank + " left.");
            System.out.print("Do you want to play again? (y/n) ");
            yesNo = console.next().toLowerCase();
            while(!yesNo.startsWith("y") && !yesNo.startsWith("n")) {
               System.out.println("That's an invalid response.");
               System.out.print("Please respond with yes (y) or no (n): ");
               yesNo = console.next();
            } 
         } else {
            System.out.println("You are out of money.");
            yesNo = "n";
         }
      }
      return bank;
   }
   
   // Adds the money to the user's bank if they win
   public void win() {
      bank += (2 * bet);
   }
   
   // Dealer's turn
   public void dealersTurn() {
      System.out.println("Dealer's turn.");
      usersTurn = false;
      System.out.println(deck.showBJTable(user, dealer, usersTurn));
      while(deck.findValueBJ(dealer) < deck.findValueBJ(user)) {
         try {
            Thread.sleep(1500);
         } catch(Exception e) {}
         dealer.add(deck.draw());
         System.out.println(deck.showBJTable(user, dealer, usersTurn));
      }
   }
   
   //Decides who the winner of the game is
   public void whoWins() {
      if(deck.findValueBJ(dealer) > deck.findValueBJ(user) && deck.findValueBJ(dealer) < 22){
         System.out.println("The dealer wins.");
      } else if(deck.findValueBJ(dealer) == deck.findValueBJ(user)) {
         System.out.println("You tied.");
         bank += bet;
      } else {
         System.out.println("Good job! You win!");
         win();
      }
   }
   
   // Sets up the game
   public void startUp() {
      deck.reset();
      deck.shuffle();
      bet = -1;
      while(bet < 1 || bet > bank) {
         System.out.print("How much do you want to bet? $");
         try{
            bet = console.nextInt();
            if(bet < 1) {
               System.out.println("Bet must be greater than 0.");
            } else if(bet > bank) {
               System.out.println("You don't have enough money to make that bet.");
            }
         } catch(Exception e) { 
            System.out.println("Invalid input. Must be an integer.");
            console.next();          
         }
      }
      bank = bank - bet;  
      user.add(deck.draw());
      dealer.add(deck.draw());
      user.add(deck.draw());
      dealer.add(deck.draw());
   }
   
   // User's turn
   public int goUserGo() {
      String option = "hit";
      boolean usersTurn = true;
      int turn = 0;
      while(option.startsWith("h") && deck.findValueBJ(user) < 21) {
         turn++;
         System.out.println(deck.showBJTable(user, dealer, usersTurn));
         System.out.println();            
         System.out.print("Would you like to hit or pass? ");
         option = console.next().toLowerCase();
         while(!option.startsWith("h") && !option.startsWith("p")) {
            System.out.print("That is an invalid response. Hit or pass? " );
            option = console.next();
         }
         if(option.startsWith("h")) {
            user.add(deck.draw());
            deck.showBJTable(user, dealer, usersTurn);
         }     
      }
      return turn;
   }
}