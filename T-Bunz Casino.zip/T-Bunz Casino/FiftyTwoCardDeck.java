// Tyler Bunnell
// This program simulates a standard fifty two card deck and can be used to play many card games

import java.util.*;

public class FiftyTwoCardDeck {
   
   private List<String> deck;
   
   // Constructor
   public FiftyTwoCardDeck() {
      deck = new ArrayList<>();
      reset();
   }
   
   // Shuffles a deck of cards
   public void shuffle() {
      Collections.shuffle(deck);
   }
   
   // Draws a card from the deck
   public String draw() {
      return deck.remove(0);
   }
   
   // Shows a hand of cards
   public String showHand(List<String> hand) {
      String result = "Your hand:\n      ";
      int size = hand.size();
      for(int i = 0; i < size; i++) {
         if(i == (size - 1)) {
            result += hand.get(i);
         } else {
            result += (hand.get(i) + "  ");
         }
      }
      return result;
   }
   
   // Shows the users hand and the rest of the cards shown in a Black Jack game
   public String showBJTable(List<String> hand, List<String> dealerHand, boolean userTurn) {
      String result = "***************************************\n\nDealer's hand: \n";
      if(userTurn) {
         result += ("      ?    " + dealerHand.get(0));
         
      } else {
         result += ("      ");
         int size = dealerHand.size();
         for(int i = 0; i < size; i++) {
               result += (dealerHand.get(i) + "  ");
         }
         result += "  Value: " + findValueBJ(dealerHand);
      }
      result += "\n \n" + showHand(hand) + "    Value: " + findValueBJ(hand);
      result += "\n\n***************************************";
      return result;
   }
   
   // Finds the value of a hand of cards with standard card values
   public int findHandValue(List<String> values) {
      int value = 0;
      String[] hand = new String[values.size()];
      for(int i = 0; i < values.size(); i++) {
         hand[i] = values.get(i);
      }
      for(int i = 0; i < hand.length; i++) {
         if(hand[i].startsWith("A")) {
            value++;
         } else if (hand[i].startsWith("J")) {
            value += 11;
         } else if (hand[i].startsWith("Q")) {
            value += 12;
         } else if (hand[i].startsWith("K")) {
            value += 13;
         } else {
            for(int j = 2; j < 11; j++) {
               if(hand[i].startsWith(j + "")) {
                  value += j;
               }
            }
         }
      }
      return value;
   }
   
   // Finds the value of a hand of cards in a game of Black Jack
   public int findValueBJ(List<String> values) {
      int value = 0;
      String[] hand = new String[values.size()];
      int size = values.size();
      int aceCounter = 0;
      for(int i = 0; i < size; i++) {
         hand[i] = values.get(i);
      }
      for(int i = 0; i < hand.length; i++) {
         if(hand[i].startsWith("J") || hand[i].startsWith("Q") || hand[i].startsWith("K")) {
            value += 10;
         } else if(hand[i].startsWith("A")) {
            aceCounter++;
         } else {
            for(int j = 2; j < 11; j++) {
               if(hand[i].startsWith(j + "")) {
                  value += j;
               }
            }
         }
      }
      for(int i = 0; i < aceCounter; i++) {
         if(value > 10) {
            value += 1;
         } else {
            value += 11;
         }
      }
      return value;
    }
   
   // removes everything from the deck and adds all the cards back in order
   public void reset() {
      while(deck.size() > 0) {
         deck.remove(0);
      }
      deck.add("A H");
      deck.add("A D");
      deck.add("A C");
      deck.add("A S");
      for(int i = 2; i < 11; i++) {
         deck.add(i + " H");
         deck.add(i + " D");
         deck.add(i + " C");
         deck.add(i + " S");
      }
      deck.add("J H");
      deck.add("J D");
      deck.add("J C");
      deck.add("J S");
      deck.add("Q H");
      deck.add("Q D");
      deck.add("Q C");
      deck.add("Q S");
      deck.add("K H");
      deck.add("K D");
      deck.add("K C");
      deck.add("K S");
   }
}