// Tyler Bunnell
// This program simulates a game of roulette

import java.util.*;
public class RoulettePlayer{
  
   private int bank;
   private Scanner console;
   private Random rand;
   private int bet;
   private int odds;
   private int spin;
   private String answerColor;
   private String theColor;
   
   public RoulettePlayer(int bank) {
      this.bank = bank;
      console = new Scanner(System.in);
      rand = new Random();
      this.bet = 0;
   }
   
   // Puts all the methods together to play the game
   public int play() {
      String yesNo = "y";
      while (bank > 0 && yesNo.equalsIgnoreCase("y")) {
         String response = makeBets();
         if (response.startsWith("h") || response.startsWith("lo")) {
            highLow();
         } else if (response.startsWith("n")) {
            numbers();
         } else if (response.startsWith("c")) {            
            color();
         } else if (response.startsWith("e")) {
            evenness();
         } else if (response.startsWith("li")) {
            lines();
         } else if (response.startsWith("t")) {
            twelves();
         }
         
         showBank();
         if(getBank() > 0) {
            System.out.print("Do you want to continue playing roulette? (y/n): ");
            yesNo = console.next();
            while (!yesNo.equalsIgnoreCase("y") && !yesNo.equalsIgnoreCase("n")) {
               System.out.println("That's an invalid response.");
               System.out.print("Please respond with yes (y) or no (n): ");
               yesNo = console.next();
            }
         }
      }
      return bank;  
   }
   
   // All the prompts and user input when the user is making their bets
   public String makeBets() {
      System.out.println("Where do you want to place this bet?");
      System.out.println("   Choices: high/low, numbers, color, evenness, lines, or twelves");
      String response = console.next().toLowerCase();
      while (!response.startsWith("h") && !response.startsWith("n") && !response.startsWith("lo")
             && !response.startsWith("c") && !response.startsWith("e")
             && !response.startsWith("li") && !response.startsWith("t")){
         System.out.println("That is an invalid response. Please try again.");
         System.out.println("Where do you want to place this bet?");
         System.out.println("   Choices: numbers, color, evenness, lines, or twelves");
         response = console.next().toLowerCase();         
      }
      System.out.println("You currently have $" + bank + ".");
      bet = 0;
      while(bet < 1 || bet > bank) {
         System.out.print("How much do you want to bet? $");
         try{
            bet = console.nextInt();
            if(bet < 1) {
               System.out.println("Bet must be greater than 0.");
            } else if(bet > bank) {
               System.out.println("You don't have enough money to make that bet.");
            }
         } catch(Exception e) { 
            System.out.println("Invalid input. Must be an integer.");
            console.next();          
         }
      }
      spin = rand.nextInt(37);
      return response;
   }
   
   // Adds to bank when user wins
   public void win(){
      System.out.println("Congratulations! You won!");
      bank = bank + (bet * odds);
   }
   
   // Subtracts bank when user loses
   public void lose(){
      System.out.println("Sorry, you lost.");
      bank = bank - bet;
   }
   
   // The prompt if the user is betting on high/low
   public void highLow(){
      odds = 1;
      System.out.print("High or low? ");
      String range = console.next().toLowerCase();
      while (!range.startsWith("h") && !range.startsWith("l")){
         System.out.print("Invalid response. Please enter high or low. ");
         range = console.next().toLowerCase();
      }
      showSpin();
      if(range.startsWith("h")) {
         if(spin < 19){
            lose();
         } else {
            win();
         }
      } else {
         if(spin > 0 && spin < 19){
            win();
         } else {
            lose();
         }
      }
   }
   
   // The prompt if the user is betting on lines
   public void lines(){
      odds = 2;
      System.out.println("(1)st line (1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34)");
      System.out.println("(2)nd line (2, 5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35)");
      System.out.println("(3)rd line (3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36)");
      String range = console.next();
      while (!range.equals("1") && !range.equals("2") && !range.equals("3")){
         System.out.print("Invalid response. Please enter 1, 2 or 3. ");
         range = console.next();
      }
      showSpin();
      if(range.equals("1")){
         if(spin==1 || spin==4 || spin==7 || spin==10 || spin==13 || spin==16 || spin==19 ||
            spin==22 || spin==25 || spin==28 || spin==31 || spin==34){
            win();
         } else{
            lose();
         }
      } else if(range.equals("2")){
         if(spin==2 || spin==5 || spin==8 || spin==11 || spin==14 || spin==17 || spin==20 ||
            spin==23 || spin==26 || spin==29 || spin==32 || spin==35){
            win();
         } else{
            lose();
         }
      } else {
         if(spin==3 || spin==6 || spin==9 || spin==12 || spin==15 || spin==18 || spin==21 ||
            spin==24 || spin==27 || spin==30 || spin==33 || spin==36){
            win();
         } else{
            lose();
         }
      }    
   }
   
   // The prompt if the user is betting on twelves
   public void twelves(){
      odds = 2;
      System.out.print("(1)st, (2)st, or (3)rd dozen? ");
      String range = console.next();
      while (!range.equals("1") && !range.equals("2") && !range.equals("3")){
         System.out.print("Invalid response. Please enter 1, 2, or 3. ");
         range = console.next();
      }
      showSpin();
      if(range.equals("1")){
         if(spin > 0 && spin < 13){
            win();
         } else{
            lose();
         }
      } else if(range.equals("2")){
         if(spin > 12 && spin < 25){
            win();
         } else{
            lose();
         }
      } else{
         if(spin > 24){
            win();
         } else{
            lose();
         }
      }
   }
   
   // The prompt if the user is betting on evenness
   public void evenness(){
      odds = 1;
      System.out.print("Even or odd? ");
      String range = console.next().toLowerCase();
      while (!range.startsWith("e") && !range.startsWith("o")){
         System.out.print("Invalid response. Please enter even or odd. ");
         range = console.next().toLowerCase();
      }
      showSpin();
      if (range.equals("even")) {
         if (spin % 2 == 0) {
            win();
         } else {
            lose();
         }
      } else {
         if (spin % 2 == 0) {
            lose();
         } else {
            win();
         }
      }
   }
   
   // The prompt if the user is betting on color
   public void color(){
      odds = 1;
      System.out.print("Do you want to bet on black or red? ");
      String betColor = console.next().toLowerCase();
      if(!betColor.startsWith("b") && !betColor.startsWith("r")){
         System.out.println("Invalid response. Colors are black and red. Try again: ");
         betColor = console.next().toLowerCase();
      }
      if(spin==1 || spin==3 || spin==5 || spin==7 || spin==9 || spin==12 || spin==14 || spin==16
         || spin==18 || spin==19 || spin==21 || spin==23 || spin==25 || spin==27 || spin==30
         || spin==32 || spin==34 || spin==36) {
         answerColor = "red";
         theColor = "r";
         showColor();
      } else if(spin == 0) {
         answerColor = "You lose haha";
         showSpin();
      } else{
         answerColor = "black";
         theColor = "b";
         showColor();
      }
      if (betColor.startsWith(theColor)){
         win();
      } else {
         lose();
      }
   }
   
   // The prompt if the user is betting on numbers
   public void numbers(){
      odds = 35;
      int number = -1;
      while (number <= 0 || number >= 36){
         System.out.print("Which number are you betting on? ");
         try {
            number = console.nextInt();
            if(number <= 0 || number >= 36) {
               System.out.println("Your number must be between 0 and 36.");
            }
         } catch(Exception e) {
            System.out.println("You must enter a number.");
            console.next();
         }
      }
      showSpin();
      if(number == spin) {
         win();
      } else {
         lose();
      }
   }
   
   // Shows the number that the roll landed on
   public void showSpin(){
      System.out.println("The number was " + spin + ".");
   }
   
   // Shows the color that the roll landed on
   public void showColor(){
      System.out.println("The color was " + answerColor + ".");
   }
   
   // Shows how much money is in the bank with a message
   public void showBank() {
      if (bank == 0) {
         System.out.println("You have no money left.");
      } else {
         System.out.println("You have $" + bank + " left.");
      }
   }
   
   // Getter for the bank
   public int getBank() {
      return bank;
   }
}