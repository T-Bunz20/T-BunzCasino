import java.util.*;

public class deckTest {
   public static void main(String[] args) {
      FiftyTwoCardDeck deck = new FiftyTwoCardDeck();
      deck.shuffle();
   }
}