// Tyler Bunnell
// Homework 1
// 9/27/2019
// CS 111 - Tatiana Harrison
// This program plays 5000 slot machines and prints how many are winners

public class Play5000SlotMachines {
   public static void main(String[] args) {
      int wins = 0;
      for(int i = 0; i < 5000; i++) {
         SlotsPlayer slot = new SlotsPlayer(1);
         if(slot.isWinner() > 0) {
            wins++;
         }
      }
      System.out.println("From 5000 slot machines, " + wins + " were winners");
   }
}