// Tyler Bunnell
// This program simulates a slot machine

import java.util.*;

public class SlotsPlayer {

   private int[] rowOne;
   private int[] rowTwo;
   private int[] rowThree;
   private int bank;
   private int bet;
   
   // constructor
   public SlotsPlayer(int bank) {
      rowOne = new int[3];
      rowTwo = new int[3];
      rowThree = new int[3];
      gambleMachine();
      this.bank = bank;
      bet = 0;
   }
   
   
   // Interacts with the user and plays the slot
   public int play() {
      Scanner console = new Scanner(System.in);
      String yesNo = "y";
      while(yesNo.startsWith("y") && bank > 0) {
         bet = -1;
         while(bet < 1 || bet > bank) {
            System.out.print("How much do you want to put in the slot machine? $");
            try{
               bet = console.nextInt();
               if(bet < 1) {
                  System.out.println("Bet must be greater than 0.");
               } else if(bet > bank) {
                  System.out.println("You don't have enough money to make that bet.");
               }
            } catch(Exception e) { 
               System.out.println("Invalid input. Must be an integer.");
               console.next();          
            }
         }
         bank = bank - bet;
         gambleMachine();
         screen();
         bank += isWinner();
         if(bank > 0) {
            System.out.println("You have $" + bank + " left.");
            System.out.print("Do you want to play again? (y/n) ");
            yesNo = console.next().toLowerCase();
            while(!yesNo.startsWith("y") && !yesNo.startsWith("n")) {
               System.out.println("That's an invalid response.");
               System.out.print("Please respond with yes (y) or no (n): ");
               yesNo = console.next();
            } 
         } else {
            System.out.println("You are out of money.");
            yesNo = "n";
         }
      }
      return bank;     
   }
   
   // Fills the slot machine with random numbers
   private void gambleMachine() {
      Random rand = new Random();
      for(int i = 0; i < 3; i++) {
         rowOne[i] = rand.nextInt(10);
      }
      for(int i = 0; i < 3; i++) {
         rowTwo[i] = rand.nextInt(10);
      }
      for(int i = 0; i < 3; i++) {
         rowThree[i] = rand.nextInt(10);
      }
   }
   
   // Returns the number of matching rows or columns times the bet to make the payout
   private int isWinner() {
      int wins = 0;
      if(rowOne[0] == rowOne[1] && rowOne[1] == rowOne[2]) {
         wins++;
      }
      if(rowTwo[0] == rowTwo[1] && rowTwo[1] == rowTwo[2]) {
         wins++;
      }
      if(rowThree[0] == rowThree[1] && rowThree[1] == rowThree[2]) {
         wins++;
      }
      for(int i = 0; i < 3; i++) {
         if(rowOne[i] == rowTwo[i] && rowOne[i] == rowThree[i]) {
            wins++;
         }
      }
      if(rowOne[0] == rowTwo[1] && rowOne[0] == rowThree[2]) {
         wins++;
      }
      if(rowOne[2] == rowTwo[1] && rowOne[2] == rowThree[0]) {
         wins++;
      }
      if(wins == 8) {
         System.out.println("Wow, you hit the jackpot!!!");
         return (bet * 100);
      } else if(wins == 0) {
         System.out.println("Sorry, you lost.");
      } else {
         System.out.println("Yay, you had " + wins + " wins.");
      }
      return ((wins * bet) * 2);
   }
   
   // Displays the slot machine screen
   private void screen(){
      System.out.println();
      System.out.println(" - - - - - -");
      System.out.println("| " + rowOne[0] + " | " + rowOne[1] + " | " + rowOne[2] + " |");
      System.out.println();
      System.out.println("| " + rowTwo[0] + " | " + rowTwo[1] + " | " + rowTwo[2] + " |");
      System.out.println();
      System.out.println("| " + rowThree[0] + " | " + rowThree[1] + " | " + rowThree[2] + " |");
      System.out.println(" - - - - - -");
      System.out.println();
   }
}