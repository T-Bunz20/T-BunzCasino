// Tyler Bunnell
// The driver class for the T-Bunz Casino. Keeps track of a user's past playthroughs
// and how much money they made or lossed in total
import java.util.*;
import java.io.*;

public class TBunzCasinoPlayer {
   public static void main(String[] args) throws FileNotFoundException {
      
      // Initializes variables
      List<String> tfdNames = new ArrayList<>(0);
      List<Integer> tfdNums = new ArrayList<>(0);
      Scanner console = new Scanner(System.in);
      String username = "";
      
      // Fills lists with the information from playerHistory.txt
      Scanner file = new Scanner(new File("playerHistory.txt"));     
      while(file.hasNextLine()) {
         tfdNames.add(file.nextLine());
         tfdNums.add(file.nextInt());
         file.nextLine();
      }
      file.close();
      
      // Introduces program and asks user if they have played before
      System.out.println("Hello! Welcome to The T-Bunz Casino!");
      System.out.print("(S)ign in or (C)reate account? ");
      String playedBefore = console.next().toLowerCase();
      while(!playedBefore.startsWith("c") && !playedBefore.startsWith("s")) {
         System.out.print("Invalid response. (S)ign in or (C)reate account? ");
         playedBefore = console.next().toLowerCase();
      }
      if(playedBefore.startsWith("s")) {
         username = hasPlayed(console, tfdNames);
         
         // Asks user if theyd like to view the leaderboard or play
         System.out.print("Would you like to (v)iew the leaderboard or (p)lay? ");
         String viewLeader = console.next().toLowerCase();
         while(!viewLeader.startsWith("v") && !viewLeader.startsWith("p")) {
            System.out.print("Invalid response. (V)iew or (P)lay? ");
            viewLeader = console.next().toLowerCase();
         }
         if(viewLeader.startsWith("v")) {
            System.out.println();
            System.out.println("********************");
            System.out.println("LEADERBOARD:");
            System.out.println(leaderboard(tfdNames, tfdNums, username));
            System.out.println("********************");
            System.out.println();
         
            System.out.print("Would you like to play? ");
            String letsPlay = console.next().toLowerCase();
            while(!letsPlay.startsWith("n") && !letsPlay.startsWith("y") && 
                  !letsPlay.startsWith("p")) {
               System.out.print("Invalid response. Would you like to play? ");
               letsPlay = console.next().toLowerCase();
            }
            if(letsPlay.startsWith("n")) {
               System.exit(0);
            }
         }
      } else {
         username = hasNotPlayed(console, tfdNames);
      }
      
      // Asks the amount of money the user came in with
      int startBank = -1;
      while(startBank < 1) {
         System.out.print("How much money did you bring in today? $");
         try {
            startBank = console.nextInt();
            if(startBank < 1) {
               System.out.println("Number must be greater than 0.");
            }
         } catch(Exception e) { 
            System.out.println("Invalid input. Must be a an integer.");
            console.next();          
         }
      }
      int bank = startBank;
      String yesNo = "y";
      
      while(yesNo.startsWith("y") && bank > 0) {
         
         // Asks what game user wants to play
         System.out.println("What game do you want to play? ");
         System.out.print("   Roulette, Slots, or Black Jack? ");
         String game = console.next().toLowerCase();
         while(!game.startsWith("r") && !game.startsWith("s") && !game.startsWith("b")) {
            System.out.print("Invalid response. Must choose either roulette, slots or black jack. ");
            game = console.next();
         }  
         System.out.println();    
         
         // Plays Roulette
         if(game.startsWith("r")) {
            RoulettePlayer rouPlay = new RoulettePlayer(bank);
            bank = rouPlay.play();
         }
         
         // Plays Slots
         if(game.startsWith("s")) {
            SlotsPlayer sloPlay = new SlotsPlayer(bank);
            bank = sloPlay.play();
         }
         
         // Plays Black Jack
         if(game.startsWith("b")) {
            BlackJackPlayer bJPlay = new BlackJackPlayer(bank);
            bank = bJPlay.play();
         }
         
         System.out.println();
         
         // Asks user if they want to play again
         if(bank > 0) {
            System.out.print("Do you want to play another game? (y/n) ");
            yesNo = console.next().toLowerCase();
            while (!yesNo.startsWith("y") && !yesNo.startsWith("n")) {
               System.out.println("That's an invalid response.");
               System.out.print("Please respond with yes (y) or no (n): ");
               yesNo = console.next();
            }
         }
      }
      
      System.out.println();
      
      // Tells how much money the user made or loss
      if(startBank < bank) {
         System.out.println("Wow! You made $" + (bank - startBank) + "!");
         System.out.println("Great job! Please come again!"); 
      } else if(startBank == bank){
         System.out.println("Looks like you broke even today. Good job! Have a nice day!");
      } else {
         System.out.println("Oh no, you lost $" + (startBank - bank) + ".");
         System.out.println("Don't you know the house always wins? Better luck next time.");
      }
      
      // Checks if user played before and will choose how to print to the file accordingly
      if(playedBefore.startsWith("s")) {
         endPlayed(username, (bank - startBank), tfdNames, tfdNums);
      } else {
         endNotPlayed(username, (bank - startBank), tfdNames, tfdNums); 
      }
   }
   
   // Has user enter their username if they have played before. Checks if username exists
   // and if the username cannot be found, will ask if user wants to try another username,
   // if not, will end the program.
   public static String hasPlayed(Scanner console, List<String> tfdNames) {
      System.out.print("Enter your username here: ");
      String username = console.next();
      boolean found = false;
      int i = 0;
      while(i < tfdNames.size() && !found) {
         if(tfdNames.get(i).equalsIgnoreCase(username)) {
            found = true;
         }
         i++;
      }
      if(!found) {
         System.out.println("Username not found.");
         System.out.print("Try again (y/n)? ");
         String yesNo = console.next().toLowerCase();
         while (!yesNo.startsWith("y") && !yesNo.startsWith("n")) {
            System.out.println("That's an invalid response.");
            System.out.print("Please respond with yes (y) or no (n): ");
            yesNo = console.next();
         }
         if(yesNo.startsWith("y")) {
            username = hasPlayed(console, tfdNames);
         } else {
            System.exit(0);
         }
      }
      return username;
   } 
   
   // Will create a new username for someone that has not played before. Will make sure username
   // is not taken and that it has at least one letter. Usernames cannot include spaces
   public static String hasNotPlayed(Scanner console, List<String> tfdNames) {
      System.out.print("Please enter a username (No Spaces): ");
      String username = console.next();
      boolean found = false;
      int i = 0;
      while(i < tfdNames.size() && !found) {
         if(tfdNames.get(i).equalsIgnoreCase(username)) {
            found = true;
         }
         i++;
      }
      if(found) {
         System.out.println("Username is already taken.");
         hasNotPlayed(console, tfdNames);
      }
      if(!hasLetter(username)) {
         System.out.println("Username must have a letter in it.");
         hasNotPlayed(console, tfdNames);
      }
      return username;
   } 
   
   // Prints the user's data at the end of a text file with everyone's data
   public static void endNotPlayed(String username, int moneyMade, List<String> tfdNames, 
                                   List<Integer> tfdNums) throws FileNotFoundException {
      PrintStream writingHistory = new PrintStream("playerHistory.txt");
      for(int i = 0; i < tfdNames.size(); i++) {
         writingHistory.println(tfdNames.get(i));
         writingHistory.println(tfdNums.get(i));
      }
      writingHistory.println(username);
      writingHistory.println(moneyMade);
      writingHistory.close();
   }
   
   // If the player has played before then will find the user's username and will add
   // their current money made value with the money made in this playthrough to 
   // update the user's data and prints it all out to a file
   public static void endPlayed(String username, int moneyMade, List<String> tfdNames,
                                List<Integer> tfdNums) throws FileNotFoundException {
      PrintStream writingHistory = new PrintStream("playerHistory.txt");
      for(int i = 0; i < tfdNames.size(); i++) {
         if(username.equalsIgnoreCase(tfdNames.get(i))) {
            writingHistory.println(username);
            writingHistory.println(moneyMade + tfdNums.get(i));
         } else {
            writingHistory.println(tfdNames.get(i));
            writingHistory.println(tfdNums.get(i));
         }
      } 
      writingHistory.close(); 
   }
   
   // Checks to make sure a String has at least one letter in it
   public static boolean hasLetter(String password) {
      for(int i = 0; i < password.length(); i++) {
         char letter = password.charAt(i);
         if(Character.isLetter(letter)) {
            return true;
         }
      }
      return false;
   }
   
   // Sorts the text file and shows the leaderboard
   public static String leaderboard(List<String> tfdNames, List<Integer> tfdNums, String user) {
      boolean change = true;
      int size = tfdNums.size();
      while(change) {
         change = false;
         for(int i = 0; i < size - 1; i++) {
            if(tfdNums.get(i) < tfdNums.get(i+1)) {
               int temp = tfdNums.remove(i);
               String tempName = tfdNames.remove(i);
               tfdNums.add(i+1, temp);
               tfdNames.add(i+1, tempName);
               change = true;
            }
         }
      }
      String result = "";
      int pos = -1;
      boolean found = false;
      while(!found)  {
         pos++;
         if(tfdNames.get(pos).equalsIgnoreCase(user)) {
            found = true;
         }
      }
      for(int i = 0; i < 3; i++) {
         result += ((i + 1) + ".) " + tfdNames.get(i) + " $" + tfdNums.get(i) + "\n");
      }
      result += ("\n" + (pos + 1) + ".) " + user + " $" + tfdNums.get(pos)); 
      return result;  
   }
}